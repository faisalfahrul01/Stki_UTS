<html>
<head>
<title>Sistem Temu Kembali</title>
<!--<link  href="../jw.png" rel="shortcut icon" type="image/png" />-->
<style>
h2 {
    background-size: 60px 40px;
	background-color: #c3d0ef;
}
a {
    font-size:13px;
}
</style>
</head>
<body>
<h2 align=center><br>Sistem Temu Kembali Informasi<br><br></h2>
<hr>
<div align=center>
| <a href="koneksi.php">Koneksi</a> |
<a href="buatberita.php">Buat Dokumen</a> |
<a href="lihatberita.php">Lihat Dokumen</a> |
<a href="lowercase.php">Lower Case Dokumen</a> |
<a href="hapustandabaca.php">Hapus Tanda Baca</a> |
<a href="tokenisasi.php">Tokenisasi Kata</a> |
<a href="hasiltokenisasikata.php">Hasil Token Kata</a> |
<a href="datastopword.php">Data Stopword</a> |
<a href="prosesstopword.php">Proses Stopword</a> |
<a href="prosesstemming.php">Proses Stemming</a> |
<a href="tf.php">Term Frequency</a> |
<a href="idf.php">Invers Document Frequency</a> |
<a href="tfidf.php">TF.IDF</a> |
</div>
<hr/>
</body>
</html>
